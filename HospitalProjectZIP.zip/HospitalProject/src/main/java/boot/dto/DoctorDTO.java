package boot.dto;

import java.util.List;

import boot.entity.Appointment;
import lombok.Data;

@Data
public class DoctorDTO {
	    private Long id;
	    private String name;
	    private String email;
	    private String age;
	    private String gender;
	    private String password;
	    private String phone;
	    private String specialization;
	    private String city;
	    private String address;
	    
	    

	    

}
