package boot.dto;

import lombok.Data;

@Data
public class RepDTO {

	 
	    private Long id;
	    private String name;
	    private String email;
	    private String phone;
	    private String password;
	    private String gender;
	    private String age;
	    private String city;
	    private String address;
	    
	    
}
