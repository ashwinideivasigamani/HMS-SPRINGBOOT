package boot.dto;

import lombok.Data;

@Data
public class PatientDTO {

	 
	    private Long id;
	    private String name;
	    private String email;
	    private String Password;
	    private String age;
	    private String gender;
	    private String phone;
	    private String address;
	    private String City;
		
}
