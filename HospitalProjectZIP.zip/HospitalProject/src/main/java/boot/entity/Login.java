package boot.entity;

import lombok.Data;

@Data
public class Login {

	private String eMail;
	private String password;
	private String userType;

	
}
